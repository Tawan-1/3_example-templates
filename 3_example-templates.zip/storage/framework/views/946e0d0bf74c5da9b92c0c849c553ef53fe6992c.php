<!-- Favicons -->
<link href="<?php echo e(asset('template/promote/assets/img/favicon.png')); ?>" rel="icon">
<link href="<?php echo e(asset('template/promote/assets/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="<?php echo e(asset('template/promote/assets/vendor/animate.css/animate.min.css')); ?> " rel="stylesheet">
<link href="<?php echo e(asset('template/promote/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('template/promote/assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('template/promote/assets/vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="<?php echo e(asset('template/promote/assets/css/style.css')); ?>" rel="stylesheet">


 

<?php /**PATH C:\xampp\htdocs\3_example-templates\resources\views/includes/promote/head.blade.php ENDPATH**/ ?>