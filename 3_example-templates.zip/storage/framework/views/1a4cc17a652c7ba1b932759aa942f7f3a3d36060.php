
<?php $__env->startSection('content'); ?>



<form
        action="<?php echo e(route('adminpage.admintype_product_add')); ?>"
        method="POST"
                    class="forms-sample">
                     <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputName1">Name</label>
                        <input type="text"  name="name" class="form-control" id="exampleInputName1" placeholder="Name">
                      </div>
                      
                      
                      <br>
                      <button type="submit" class="btn btn-primary mr-2">Add</button>
                      <button type="reset" class="btn btn-primary mr-2">Reset</button>
                      <button class="btn btn-dark">Cancel</button>
                    </form>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\3_example-templates\resources\views/adminpage/admintype_product_add.blade.php ENDPATH**/ ?>