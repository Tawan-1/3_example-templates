
<?php $__env->startSection('content'); ?>

<div class="pcoded-main-container">
  <div class="pcoded-wrapper">
    <div class="pcoded-content">
      <div class="pcoded-inner-content">
        <div class="main-body">
          <div class="page-wrapper">
           
            <div class="row">

                          <div class ="col-12">
                          <div class="card">
                                      <div class="card-header">
                                      <a href="/admin/type_product/formadd" class="btn btn-primary">
                                          เพิ่ม
                                           </a>
                                      </div>
                                      <div class="card-body table-border-style">
                                          <div class="table-responsive">
                                              <table class="table table-hover">
                                                  <thead>
                                                      <tr>
                                                          <th>ลำดับ</th>
                                                          <th>ชื่อประเภทสินค้า</th>
                                                          <th>แก้ไข</th>
                                                          <th>ลบ</th>
                                                      </tr>
                                                  </thead>
                                                  <tbody>
                                                      <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      <tr>
                                                          <td><?php echo e($item->id); ?></td>
                                                          <td><?php echo e($item->name); ?></td>
                                                          
                                                          <td> <a href="<?php echo e(url('/admin/detail/edit/'. $item->id)); ?>" class="btn btn-warning rounded-pill">
                                                            แก้ไข</a> </td>
                                                          <td> <a href="<?php echo e(url('/admin/detail/delete/'. $item->id)); ?>" class="btn btn-warning rounded-pill">
                                                            ลบ</a></td>   
                                                         
                                          </a>
                                                                                               
                                          </tr>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                  
                                                  </tbody>
                                              </table>
                                          </div>
                                      </div>
                                  </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\3_example-templates\resources\views/adminpage/admintype_product.blade.php ENDPATH**/ ?>