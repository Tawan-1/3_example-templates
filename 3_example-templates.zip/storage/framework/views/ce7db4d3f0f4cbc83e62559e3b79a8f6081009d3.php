<!-- Vendor JS Files -->
<script src="<?php echo e(asset('template/promote/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/promote/assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/promote/assets/vendor/php-email-form/validate.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(asset('template/promote/assets/js/main.js')); ?>"></script>

 <?php /**PATH C:\xampp\htdocs\3_example-templates\resources\views/includes/promote/footer.blade.php ENDPATH**/ ?>