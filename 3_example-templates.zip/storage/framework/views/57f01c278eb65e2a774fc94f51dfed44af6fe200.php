<!DOCTYPE html>
<html>
    
<head>
    <?php echo $__env->make('includes.promote.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    
    <header>
        <?php echo $__env->make('includes.promote.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>

    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <footer class="row">
        <?php echo $__env->make('includes.promote.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>

</body>
</html><?php /**PATH C:\laragon\www\learnlaravel\2_example-templates\resources\views/layouts/promote.blade.php ENDPATH**/ ?>