<header id="header" class="fixed-top d-flex align-items-cente">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-lg-between">

      <h1 class="logo me-auto me-lg-0"><a href="index.php">Hint Coffee Roaster</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto me-lg-0"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="<?php echo e(url('/')); ?>">Home</a></li>
          <li><a class="nav-link scrollto" href="<?php echo e(url('/house-blend')); ?>">House Blend</a></li>
          <li><a class="nav-link scrollto" href="single-origin.php">Single Orgin</a></li>
          <li><a class="nav-link scrollto" href="beverage.php">Beverage Menu</a></li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>

 <?php if(Route::has('login')): ?>
       <?php if(auth()->guard()->check()): ?>
          <li><a class="nav-link scrollto" href="<?php echo e(url('/admin/home')); ?>">admin</a></li>
 <?php else: ?>

          <li><a class="nav-link scrollto" href="<?php echo e(route('login')); ?>">Log in</a></li>

 <?php if(Route::has('register')): ?>


          <li><a class="nav-link scrollto" href="<?php echo e(route('register')); ?>">Register</a></li>

 <?php endif; ?>
                     <?php endif; ?>



<?php endif; ?>       

 <!-- <?php if(Route::has('login')): ?>
                <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Log in</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" class="ml-4 text-sm text-gray-700 dark:text-gray-500 underline">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
 -->

        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
      <a href="#book-a-table" class="book-a-table-btn scrollto d-none d-lg-flex">Booking</a>

    </div>
  </header><?php /**PATH C:\laragon\www\learnlaravel\3_example-templates\resources\views/includes/promote/header.blade.php ENDPATH**/ ?>