<footer class="footer">
    <div><a href="https://coreui.io">CoreUI </a><a href="https://coreui.io">Bootstrap Admin Template</a> © 2022 creativeLabs.</div>
    <div class="ms-auto">Powered by&nbsp;<a href="https://coreui.io/docs/">CoreUI UI Components</a></div>
  </footer>
</div>

   <!-- CoreUI and necessary plugins-->
   <script src="{{ asset('template/admin/vendors/@coreui/coreui/js/coreui.bundle.min.js') }} "></script>
   <script src="{{ asset('template/admin/vendors/simplebar/js/simplebar.min.js') }}"></script>
   <!-- Plugins and scripts required by this view-->
   <script src="{{ asset('template/admin/vendors/chart.js/js/chart.min.js') }}"></script>
   <script src="{{ asset('template/admin/vendors/@coreui/chartjs/js/coreui-chartjs.js') }}"></script>
   <script src="{{ asset('template/admin/vendors/@coreui/utils/js/coreui-utils.js') }}"></script>
   <script src="{{ asset('template/admin/js/main.js') }}"></script>