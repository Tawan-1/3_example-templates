<!-- Vendor JS Files -->
<script src="{{ asset('template/promote/assets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('template/promote/assets/vendor/swiper/swiper-bundle.min.js') }}"></script>
<script src="{{ asset('template/promote/assets/vendor/php-email-form/validate.js') }}"></script>

<!-- Template Main JS File -->
<script src="{{ asset('template/promote/assets/js/main.js') }}"></script>

 {{-- {{ asset('template/promote/') }} --}}