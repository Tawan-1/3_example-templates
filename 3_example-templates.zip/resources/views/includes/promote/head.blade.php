<!-- Favicons -->
<link href="{{ asset('template/promote/assets/img/favicon.png') }}" rel="icon">
<link href="{{ asset('template/promote/assets/img/apple-touch-icon.png') }}" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="{{ asset('template/promote/assets/vendor/animate.css/animate.min.css') }} " rel="stylesheet">
<link href="{{ asset('template/promote/assets/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('template/promote/assets/vendor/bootstrap-icons/bootstrap-icons.css') }}" rel="stylesheet">
<link href="{{ asset('template/promote/assets/vendor/swiper/swiper-bundle.min.css') }}" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="{{ asset('template/promote/assets/css/style.css') }}" rel="stylesheet">


 {{-- {{ asset('template/promote/') }} --}}

